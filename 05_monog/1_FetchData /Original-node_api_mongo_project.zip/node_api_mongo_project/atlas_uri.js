module.exports = uri =
    "mongodb+srv://admin:<yourpassword>@jdatastructures.vppue.mongodb.net/?retryWrites=true&w=majority&appName=jdatastructures"